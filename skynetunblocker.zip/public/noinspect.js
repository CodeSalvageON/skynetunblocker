document.addEventListener('contextmenu', function(e) {
  e.preventDefault();
});